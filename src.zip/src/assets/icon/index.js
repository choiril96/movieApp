import Home from './home.svg'
import Akun from './akun.svg'
import Favorite from './favorite.svg'
import Search from './search.svg'

export { Home, Akun, Favorite, Search }