import SplashBackground from "./Splash.png";
import Pilihlogin from "./pilihlogin.png";
import Logo from "./logo.png";
import Discover from "./Register.png"

export {SplashBackground, Pilihlogin, Logo, Discover}