import Home from './home';
import Akun from './akun';
import Pilihlog from './pilihlog';
import Splash from './splash';
import Search from './search';
import Favorite from './favorite';
import Streaming from './streaming';

export {Home, Akun, Pilihlog, Splash, Search, Favorite, Streaming}