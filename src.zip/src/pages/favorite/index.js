import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const Favorite = () => {
    return (
        <View>
            <Text>Halaman Favorit</Text>
        </View>
    )
}

export default Favorite

const styles = StyleSheet.create({})
