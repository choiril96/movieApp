import React from 'react'
import { StyleSheet, Text, View } from 'react-native'

const 
Search = () => {
    return (
        <View>
            <Text>Halaman Search</Text>
        </View>
    )
}

export default Search

const styles = StyleSheet.create({})
